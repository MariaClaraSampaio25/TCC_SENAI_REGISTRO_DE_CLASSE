<?php
include 'conecta.php';
$id = $_GET['id'];
$sql2= "SELECT *FROM atividades WHERE id_turma= $id";
$result = $conn-> query($sql2);
if ($result-> num_rows>0){
    echo "<script language = 'javascript' type= 'text/javascript'> 
    alert ('Essa turma possui atividade!');
    window.location.href='professor.php';
</script>";
} 
else{
    $sql = "DELETE FROM turma WHERE id=$id";
    if (mysqli_query($conn, $sql)){
        echo "<script language = 'javascript' type= 'text/javascript'> 
    window.location.href='professor.php';
</script>";
    }
    else{
        echo "<script language = 'javascript' type= 'text/javascript'> 
    alert ('Não foi possivel excluir!');
    window.location.href='professor.php';
   </script>";
    }
}
mysqli_close($conn);

?>